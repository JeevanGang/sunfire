A module that lets the user expand/restore the dialog box size through a button
in the upper right corner (imitating most windows managers).
It also adds draggable support to the dialogs.
