* Anthony Muschang <anthony.muschang@acsone.eu>
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Holger Brunn <hbrunn@therp.nl>
* Siddharth Bhalgami <siddharth.bhalgami@gmail.com>
* Wolfgang Pichler <wpichler@callino.at>
* David Vidal <david.vidal@tecnativa.com>
* Quentin Theuret <quentin.theuret@amaris.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza <pedro.baeza@tecnativa.com>
  * Jairo Llopis <jairo.llopis@tecnativa.com>
