Every user without *Export Data* permission won't have the option available.
