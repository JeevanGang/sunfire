Enable the group "Export Data group" to the users who are allowed to
make use of the option 'Export'.
