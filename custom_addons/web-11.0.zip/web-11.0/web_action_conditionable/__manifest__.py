{
    "name": 'web_action_conditionable',
    "version": "11.0.1.0.0",
    "depends": [
        'base',
        'web',
    ],
    'data': ['views/view.xml'],
    "author": "Cristian Salamea,Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/web",
    "license": "AGPL-3",
    'installable': True,
}
