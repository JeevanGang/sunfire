* Mantavya Gajjar <mga@openerp.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Jay Vora (SerpentCS) for their alternative implementation
* Aldo Soares <soares_aldo@hotmail.com>
* Meet Dholakia <meetcomputer009@gmail.com>
* Alexandre Díaz <dev@redneboa.es>
