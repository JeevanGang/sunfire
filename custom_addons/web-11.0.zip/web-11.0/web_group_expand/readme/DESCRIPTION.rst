A group by list can be expanded and collapased with buttons

You'll see two buttons appear on top right corner of the list when you perform
a group by with which you can expand and collapse grouped records by level.
