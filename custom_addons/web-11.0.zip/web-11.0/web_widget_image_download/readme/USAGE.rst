To use this module, an example path is:

#. Go to the section `Contacts`.
#. Click on a contact.
#. Edit the contact.
#. Click the `Download` button (between `Edit` and `Clear`).
