* Adil Houmadi <adil.houmadi@gmail.com>
* Enric Tobella <etobella@creublanca.es>
* Nicolas JEUDY (Sudokeys) <https://www.github.com/njeudy>
* Alexandre Díaz <dev@redneboa.es>
