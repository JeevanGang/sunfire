Odoo List View Freeze Header
===========================

This project aims to give to you the function to Freeze Header

[//]: # (addons)
Available addons
----------------
addon | version | summary
--- | --- | ---
[web_list_freeze_header](web_list_freeze_header/) | 9.0.1.0.0 | Odoo List View Freeze Header

