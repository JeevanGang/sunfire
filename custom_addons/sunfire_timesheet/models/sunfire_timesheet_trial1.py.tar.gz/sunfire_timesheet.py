from odoo import api, fields, models
import datetime

class sunfire_timesheet(models.Model):
    _name = 'sunfire.timesheet'
    _rec_name='timesheet_date'
    _sql_constraints = [ ('unique_date', 'unique(timesheet_date,create_uid)', 'Timesheet of the date entered already exists')	]
    name = fields.Char(string='Name')
    timesheet_date=fields.Date("Timesheet Date",required=True)
    timesheet_line=fields.One2many("sunfire.timesheet.line","timesheet_id",string="XYZ")
    total_time = fields.Float(string='Total time(minuntes)',compute='compute_time')
    total_time_hrs=fields.Char(string="Total Time (hh:mm)",compute='compute_time',readonly=True)
    
    @api.depends('timesheet_line.timespent')
    def compute_time(self):
        for line in self:
            temp=datetime.timedelta(hours=0.0)
            if line.timesheet_line:
                for time in line.timesheet_line:
                    if time.timespent:
                        temp+=datetime.timedelta(hours=time.timespent)
                line.total_time_hrs=str(temp).rsplit(':',1)[0]
                print(line.total_time_hrs)

class sunfire_timesheet_line(models.Model):
    _name="sunfire.timesheet.line"
    
    category=fields.Many2one('category.info',string="Category")
    sub_category=fields.Many2one('sub_category.info',string='Sub-category')
    customer=fields.Many2one('res.partner',string='Customer')
    timespent=fields.Float("Time Spent")
    timesheet_id=fields.Many2one('sunfire.timesheet',string="XYZ")
    remark=fields.Char(string="Remarks")
    rep_date=fields.Date(related="timesheet_id.timesheet_date")
    outcome=fields.Char(string="Outcome")
    poa=fields.Char(string="POA")
    role_type=fields.Many2one('approval_types.info',string="Role")
    
    def set_role(self):
        app_obj=self.env['approval_type_line.info']
        app_id=app_obj.search([('users','=',self.env.uid)])
        print("app_id",app_id)
        if app_id:
            li=[]
            domain={}
            for r in app_id:
                li.append(r.approval_id.id)
                print(li)
            domain['role_type']=[('id','in',li)]
        return domain   
                
    def set_categ(self):
        #app_obj=self.env['approval_type_line.info']
        #app_id=app_obj.search([('users','=',self.env.uid)])
        #print("app_id",app_id)
        for order in self:
            if order.role_type:
                li=[]
                domain={}
                sub_cat_obj=order.env['category.info']
                sub_cat_ids=sub_cat_obj.search([('role','=',order.role_type.approval_type)])
                for j in sub_cat_ids:
                    li.append(j.id)
                domain['category']=[('id','in',li)]
        return domain    
    @api.onchange('category')
    def set_sub_categ(self):
        catg_obj=self.env['category.info']
        subcatg_list=[]
        domain={}
        for order in self:
            if order.category:
                for ids in order.category:
                    catg_ids=catg_obj.search([('category','=',ids.category),('role','=',order.role_type.approval_type)])
                    #print("catg_ids============>",catg_ids)
                    for order in catg_ids:
                        for ids in order.catg_line:
                            subcatg_list.append(ids.id)
                            print(subcatg_list)
                        domain['sub_category']=[('id','in',subcatg_list)]
                        print("domain====>",domain['sub_category'])
        return {"domain":domain}
    
    @api.onchange('role_type')
    def onchgcatg(self):
        domain=self.set_role()
        #print(domain)
        if self.role_type:
            domain=self.set_categ()
        return {'domain':domain}